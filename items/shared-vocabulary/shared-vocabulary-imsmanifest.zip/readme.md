Intended use of these items is to exercise all of the shared vocabulary in QTIv3.
