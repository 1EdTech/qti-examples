{   "waitSeconds": 60,
        "paths": {
            "jquery": "https://code.jquery.com/jquery-2.2.2.min",
            "helpers": "shared/helpers",
            "baseBoundTemplate": "shared/baseBoundTemplate",
            "pnp": "shared/pnp",
            "eve": "modules/lib/eve",
            "raphael": "modules/lib/raphael",
            "handlebars": "https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.10/handlebars.amd.min",
            "boxMultiplication": "modules/box_multiplication",
            "boxMultiplication_css": "modules/box_multiplication_css",
            "shadingD": "modules/shading_deps",
            "tap": "modules/tap"
        }
}

