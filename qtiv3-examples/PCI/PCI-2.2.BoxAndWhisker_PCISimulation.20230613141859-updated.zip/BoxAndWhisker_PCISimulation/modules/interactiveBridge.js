/** ItemBridge: A Custom Interaction Hook implemented as an AMD Module. */
/** Authors: Jun Liu, Paul Grudnitski */
/** Created: 12/4/2019 */
define("Bridge", ["qtiCustomInteractionContext", "ETS_SIM_CSS", "SimulationRuntime"], function (qct, csstool, etsPCI, testletCustom) {

  // Instead of hard-wiring this, instead take the value from the end of the typeIdentifier.
  // Assign a generic name at first
  let item_name = "ETSPCI";

  const cDataToJson = str => {
    let mystr1 = str.replace("<!--[CDATA[", "");
    let mystr2 = mystr1.replace("]]-->", "");
    let jsonfile = JSON.parse(mystr2);
    return jsonfile;
  };

  const getConfigs = (paramObj, id, state, response) => {
    const configs = {};

    Object.keys(paramObj).forEach(key => {
      if (key === "params") return;
      configs[key] = configs[key] || paramObj[key];
    });

    const entries = paramObj.params;
    console.log("params:", entries)
    if (entries != null) {
      for (let prop in entries) {
        configs[prop] = configs[prop] || entries[prop];
      }
    }
    configs.accnum = id;
    configs.savedItemResponse = response;
    configs.savedItemState = state;

    return configs;
  };

  const interactiveItemHook = {
    id: -1,

    // MUST MATCH responseIdentifier of this interaction in the item xml.  Set this during initialize.
    identifier: "",

    // MUST MATCH customInteractionTypeIdentifier in the item xml.
    // Assign a generic name at first
    typeIdentifier: "ets.org:pci:TestletSimulation",

    accnum: "none",
    container: null,
    config: null,
    configs: null,
    interaction: null,
    state: "",
    response: "",
    record: null,
    log: "",
    paramsObj: null,

    /** @returns {String} The class/type of the Custom Interaction Hook */
    getTypeIdentifier() {
      return this.typeIdentifier;
    },

    /**
     * This method initializes the Custom Interaction Hook Instance.
     * @param {String} id - The Id parameter is the custom is a system generated id.
     * @param {Node} dom - The XMLNode parameter is the custom interaction root XML node displayed by the rendering engine.
     * @param {Object} config - The config parameter may be undefined or a JSON object representing the configuration.
     */
    initialize(id, dom, config, state = "", response = "") {
      console.log("PCI MODULE[" + this.getTypeIdentifier() + "] configuration:", config);
      item_name = dom.getElementsByTagName("div")[0].className;

      const item_top_container = dom.getElementsByTagName("div")[0].id,
        prompt_container = item_top_container + "_prompt",
        pci_container = item_top_container + "_canvas";

      const selectors = {
        prompt: "#" + prompt_container,
        canvas: "#" + pci_container
      };

      if (id) this.id = id;

      // Important: Get the responseIdentifier property passed in the config as indicated by QTI3 BPIG Section 3.
      if (config.hasOwnProperty("responseIdentifier")) {
        this.identifier = config.responseIdentifier;
      } else {
        // Delivery platform did not provide a responseIdentifier.  This is an error.
        // TODO: Initialize this.identifier to some other default.
      }

      this.dom = dom;
      this.config = config;
      this.state = state || "";
      this.response = response || "";
      this.container = document.getElementById(pci_container);

      // Initialize the record that contains the "state" and "response" fields.
      this.resetResponse();

      if (item_name === "Testlet") {
        csstool.applyCSS(dom);
        console.log("csstool:", csstool)

        console.log("testlet:", etsPCI)

        this.interaction = etsPCI;
        //add "this" as param to init
        this.interaction.initialize(
          this,
          this.container,
          "{}",
          "{}",
          testletCustom
        );
      } else {

        // config contains top-level property called "properties" as indicated by QTI3 BPIG Section 3.
        // According to the Properties defined in the XML, "params" is a property/key.
        const tempdata = config.platform === 'iCAT' ? cDataToJson(config.params) : cDataToJson(config.properties.params);
        const configs = getConfigs(tempdata, this.id, this.state, this.response);
        this.paramsObj = {
          params: {
            savedItemState: "",
            language: "ENG",
            jsonParam: configs
          }
        };

        const prompt = dom.querySelector(selectors.prompt);
        const canvas = dom.querySelector(selectors.canvas);
        // prompt.innerHTML = dom.getAttribute("prompt") || "";

        // this.container = document.getElementById(pci_container);
        this.configs = configs;

        console.log("PCI MODULE[" + this.getTypeIdentifier() + "] responseIdentifier:", this.identifier);
        console.log("PCI MODULE[" + this.getTypeIdentifier() + "] htmlNode:", dom);
        console.log("PCI MODULE[" + this.getTypeIdentifier() + "] SimulationRuntime:", etsPCI);
        console.log("PCI MODULE[" + this.getTypeIdentifier() + "] itemName:", item_name);
        console.log("PCI MODULE[" + this.getTypeIdentifier() + "] container:", this.container);
        console.log("PCI MODULE[" + this.getTypeIdentifier() + "] paramsObj:", this.paramsObj);

        // csstool is a js module.
        csstool.applyCSS(dom);

        if (this.config.platform === 'iCAT') {

          this.interaction = ETS.i[item_name].newInstance(
            this,
            this.container,
            this.paramsObj,
            this.state,
            this.response
          );
          console.log("local tester works....")

        } else {
          this.interaction = etsPCI.i[item_name].newInstance(
            // this.interaction = ETS.i[item_name].newInstance(
            this,
            this.container,
            this.paramsObj,
            this.state,
            this.response
          );
          console.log("tn8 player works...")

        }

         // Always notify the context when initialize is complete.change  this later on for iic's
      qct.notifyReady(this.id);
      }

      // cal only after initialization is done
      //qct.notifyReady(this.id);
     
    },

    //add this notify read to listen 
    notifyReady(id)
    {
      this.id=id;
      console.log("calling notify ready interaction context")
      qct.notifyReady(id);
     
    },

    setResponse(response) {
      // response param is an object.  No need for JSON.parse(response).
      this.record = response;
      this.response = this.record.record[0].base.string;
      this.state = this.record.record[1].base.string;

      this.destroy();

      if (item_name === "Testlet") {
        //restore function in testlet
        this.interaction = etsPCI;
         //add "this" as param to init
        this.interaction.initialize(
          null,  // add null "this" as param to init. null prevents notifyReady.
          this.container,
          this.state,
          this.response,
          testletCustom
        );
      } else {
        this.paramsObj.params.jsonParam.savedItemResponse = this.response;
        this.paramsObj.params.jsonParam.savedItemState = this.state;
        if (this.config.platform === 'iCAT') {
          console.log("item:", item_name)
          this.interaction = ETS.i[item_name].newInstance(
            this,
            this.container,
            this.paramsObj,
            this.state,
            this.response
          );
        } else {
          this.interaction = etsPCI.i[item_name].newInstance(
            this,
            this.container,
            this.paramsObj,
            this.state,
            this.response
          );
        }
      }

    },

    getResponse() {
      // Important! this.record follows the PCI 1.0 json response standard for record cardinality.
      // https://www.imsglobal.org/spec/pci/v1p0
      // Return the unstringified object.
      if (item_name === "Testlet") {
        console.log("itemState:-----", JSON.stringify(this.interaction.itemState))
        console.log("itemResponse:----", JSON.stringify(this.interaction.itemResponse))
        this.record = {
          "record": [
            { "name": "response", "base": { "string": JSON.stringify(this.interaction.itemResponse) } },
            { "name": "state", "base": { "string": JSON.stringify(this.interaction.itemState) } }
          ]
        };
      }

      return this.record;
    },

    resetResponse() {
      // Important! this.record follows the PCI 1.0 json response standard for record cardinality.
      // https://www.imsglobal.org/spec/pci/v1p0
      this.record = {
        "record": [
          { "name": "response", "base": { "string": "" } },
          { "name": "state", "base": { "string": "" } }
        ]
      };
    },

    saveResponseforExtUse(response) {
      // response is a string
      this.response = response;
      this.saveRecord();
    },

    saveItemStateonExt(state) {
      // state is a string
      this.state = state;
      this.saveRecord();
    },

    saveRecord() {
      //
      // Note: this.response and this.state are strings.
      //
      // Important: this.record follows the PCI 1.0 json response standard for record cardinality.
      // https://www.imsglobal.org/spec/pci/v1p0
      //

      this.record = {
        "record": [
          { "name": "response", "base": { "string": JSON.stringify(this.response) } },
          { "name": "state", "base": { "string": JSON.stringify(this.state) } }
        ]
      };
    },

    destroy() {
      this.interaction.destroy();
      this.interaction = null;
      this.container.innerHTML = "";
    },

    setState: function (state) { },

    getState: function () { },

    resetState: function () { },

    getAnswered: function () { },

    getInstance: function (dom, configuration, state) { },

    setSerializedState: function (state) { },

    getSerializedState: function () { },

    resetSerializedState: function () { },

    interactionFinished: function () {
      // Clean up here.
      this.destroy();
      qct.notifyDone(this.id);
    }
  };

  // The Custom Interaction Hook registers to the interactiveItemHook object.
  qct.register(interactiveItemHook);
});
