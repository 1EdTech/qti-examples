"use strict";
define("ETS_SIM_CSS",[], function() {
  var css = `<style>
  
/* ONE-COLOR BOX AND WHISKER PARAMETER OVERRIDE 
.ets-interaction-BoxAndWhisker-rect-default, .ets-interaction-BoxAndWhisker-rect-high, .ets-interaction-BoxAndWhisker-rect-low {
    fill: #B8E2FF !important;
}		*/
		
.ets-interaction-BoxAndWhisker-chartFrame{
	stroke			: #CCC;
	stroke-width	: 3;
	fill			: none;
}

.iic-body-high .ets-interaction-BoxAndWhisker-chartFrame{
	stroke			: #757575;
}



.ets-interaction-BoxAndWhisker-chartMinorLine{
	stroke			: #949494;
	stroke-width	: 2;
}
.iic-body-high line.ets-interaction-BoxAndWhisker-chartMinorLine {
    stroke: #757575;
}


.ets-interaction-BoxAndWhisker-chartMajorLine{
	stroke			: #949494;
	stroke-width	: 3;
	stroke-linecap: round;
}	

.iic-body-high line.ets-interaction-BoxAndWhisker-chartMajorLine {
    stroke: #757575;
}


.ets-interaction-BoxAndWhisker-verticalLine{
	stroke			: #949494;
	stroke-width	: 2;
	stroke-dasharray: 12 8;
}
.iic-body-high line.ets-interaction-BoxAndWhisker-verticalLine {
    stroke: #757575;
	stroke-dasharray: 12 8;
	stroke-linecap: round;
}

.iic-body-high text.ets-interaction-BigDisplayText {
    fill: white !important;
}


.ets-interaction-BoxAndWhisker-text{
	fill			: black;
}

.iic-body-high .ets-interaction-BoxAndWhisker-text{
	fill			: white;
}	




.ets-interaction-BoxAndWhisker-cir {
	stroke			: #0855B2;
	stroke-width: 3 !important;
	fill			: white;
	r: 9;
}

.ets-interaction-BoxAndWhisker-cir-high, circle.ets-interaction-itemCirEmpty-high, .iic-body-high .ets-interaction-BoxAndWhisker-cir {
/*	stroke			: #fff;
	stroke-width: 3 !important;
	fill			: #0072E1;
	r: 9;*/	
	stroke			: #0855B2;
	stroke-width: 3 !important;
	fill			: white;
	r: 9;
}

circle.ets-interaction-itemCirEmpty {
/*	stroke			: #0855B2;
	stroke-width: 3 !important;
	fill			: white;
	r: 9;*/
	stroke			: #0855B2;
	stroke-width: 3 !important;
	fill			: white;
	r: 9;
}



.iic-body-high circle.ets-interaction-itemCirEmpty {
    stroke: white !important;
    fill: black !important;
}

.iic-body-low circle.ets-interaction-itemCirEmpty {
    stroke: black !important;
    fill: #f5f5dc !important;
}









.ets-interaction-blocker{
	stroke			: none;
	fill			: #aaa;
	opacity			: 0.0;
}







/*! Version IIC-20180725-01 */
.text-xsmall{font-size:.6em !important;}.text-small{font-size:.8333em !important;}.text-medium{font-size:1em !important;}.text-large{font-size:1.25em !important;}.text-xlarge{font-size:1.4em !important;}*{-webkit-tap-highlight-color:transparent;}.iic-stage,.iic-stage p,#iic-stage,#iic-stage p,.iic-stage input,#iic-stage input,.iic-stage text,#iic-stage text{font-family:Calibri,Arial,sans-serif !important;font-size:24px;touch-action:none;}.iic-stage,#iic-stage{transform-origin:top left;-webkit-transform-origin:top left;-moz-transform-origin:top left;-o-transform-origin:top left;-ms-transform-origin:top left;}.top{user-select:none;}.iic-stage.iic-body-default,#iic-stage.iic-body-default{background-color:#fff;color:#000;fill:#000;}.iic-stage.iic-body-high,#iic-stage.iic-body-high{background-color:#000;color:#fff;fill:#fff;}.iic-stage.iic-body-low,#iic-stage.iic-body-low{background-color:#f9f9e9;color:#000;fill:#000;}.iic-tts{cursor:default !important;pointer-events:none;}.iic-tts-cover{cursor:default;height:0;left:0;position:absolute;top:0;width:0;z-index:999;}#iic-stage.iic-tts .iic-tts-cover{height:100%;width:100%;}.iic-button::-moz-focus-inner,button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn)::-moz-focus-inner,input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn)::-moz-focus-inner{border:0;}#reflectXButton::-moz-focus-inner,#reflectYButton::-moz-focus-inner{border:0;}.iic-button,button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background:none;background-color:#fff;border:none;border-color:#949494;border-radius:.2em;border-style:solid;border-width:.1em;box-shadow:none;cursor:pointer;display:inline-block;font-family:Calibri,Arial,sans-serif !important;font-size:1em;font-weight:normal;line-height:normal;margin-bottom:0;margin-left:0;margin-right:0;margin-top:0;padding-bottom:.3em;padding-left:.5em;padding-right:.5em;padding-top:.3em;text-transform:initial;letter-spacing:.02em;transition:background .2s,border .2s,box-shadow .2s,color .2s;width:auto;box-sizing:content-box;color:#0059a8;}.iic-button:hover:enabled,button:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){border-color:#616161;box-shadow:0 .07em .1em rgba(0,0,0,.25);}.iic-button:focus:enabled,button:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){border-color:#616161;outline-color:initial;outline-offset:-5px;outline-style:dotted;outline-width:1px;}.iic-button:active:enabled,button:active:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:active:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#f0f0f0;border-color:#616161;box-shadow:none;}.iic-button:disabled,button:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-button .iic-button.unselectable,button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn) .iic-button.unselectable,input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn) .iic-button.unselectable,.iic-button button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn) button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn) button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-button input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn) input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn) input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#e5e5e5 !important;border-color:transparent !important;color:#909090;cursor:default;pointer-events:none;}.iic-stage.iic-body-high .iic-button,.iic-stage.iic-body-high button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button,#iic-stage.iic-body-high button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#000;border-color:#999;color:#66b1ff;}.iic-stage.iic-body-high .iic-button:focus:enabled,.iic-stage.iic-body-high button:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input[type="button"]:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button:focus:enabled,#iic-stage.iic-body-high button:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input[type="button"]:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){outline-offset:-5px;}.iic-stage.iic-body-high .iic-button:hover:enabled,.iic-stage.iic-body-high button:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input[type="button"]:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button:hover:enabled,#iic-stage.iic-body-high button:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input[type="button"]:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#2a2a2a !important;border-color:#ddd !important;}.iic-stage.iic-body-high .iic-button:active,.iic-stage.iic-body-high button:active:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input[type="button"]:active:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button:active,#iic-stage.iic-body-high button:active:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input[type="button"]:active:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#f0f0f0;border-color:#ddd !important;box-shadow:none;}.iic-stage.iic-body-high .iic-button:active:hover:enabled,.iic-stage.iic-body-high button:active:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input[type="button"]:active:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button:active:hover:enabled,#iic-stage.iic-body-high button:active:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input[type="button"]:active:hover:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#2a2a2a !important;border-color:#ddd !important;box-shadow:none;}.iic-stage.iic-body-high .iic-button:disabled,.iic-stage.iic-body-high button:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input[type="button"]:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high .iic-button.unselectable,.iic-stage.iic-body-high button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-high input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button:disabled,#iic-stage.iic-body-high button:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input[type="button"]:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high .iic-button.unselectable,#iic-stage.iic-body-high button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-high input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#2e2e2e !important;border-color:#39f;border-color:transparent !important;color:#626262 !important;box-shadow:none;}.iic-stage.iic-body-low .iic-button,.iic-stage.iic-body-low button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-low input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low .iic-button,#iic-stage.iic-body-low button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#f9f9e9;border-color:#999;}.iic-stage.iic-body-low .iic-button:focus:enabled,.iic-stage.iic-body-low button:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-low input[type="button"]:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low .iic-button:focus:enabled,#iic-stage.iic-body-low button:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low input[type="button"]:focus:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){outline-offset:-5px;}.iic-stage.iic-body-low .iic-button:active:enabled,.iic-stage.iic-body-low button:active:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-low input[type="button"]:active:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low .iic-button:active:enabled,#iic-stage.iic-body-low button:active:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low input[type="button"]:active:enabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#f0f0dc;border-color:#616161 !important;box-shadow:none;}.iic-stage.iic-body-low .iic-button:disabled,.iic-stage.iic-body-low button:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-low input[type="button"]:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-low .iic-button.unselectable,.iic-stage.iic-body-low button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-stage.iic-body-low input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low .iic-button:disabled,#iic-stage.iic-body-low button:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low input[type="button"]:disabled:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low .iic-button.unselectable,#iic-stage.iic-body-low button.unselectable:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),#iic-stage.iic-body-low input.unselectable[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){background-color:#dcdcc8 !important;border-color:transparent !important;color:#8d8d7a !important;}.iic-button-alt,.aButton-left,.aButton-right,.ets-interaction-nav-btn{background:none;background-color:#fff;border:none;border-color:#949494;border-radius:.2em;border-style:solid;border-width:.1em;box-shadow:none;cursor:pointer;display:inline-block;font-family:Calibri,Arial,sans-serif !important;font-size:1em;font-weight:normal;line-height:normal;margin-bottom:0;margin-left:0;margin-right:0;margin-top:0;padding-bottom:.3em;padding-left:.5em;padding-right:.5em;padding-top:.3em;text-transform:initial;letter-spacing:.02em;transition:background .2s,border .2s,box-shadow .2s,color .2s;width:auto;color:#fff;background-color:#0068d1;border:.083em solid transparent;cursor:pointer;font-size:1em;font-weight:normal;margin:0 !important;}.iic-button-alt:focus:enabled,.aButton-left:focus:enabled,.aButton-right:focus:enabled,.ets-interaction-nav-btn:focus:enabled{outline-color:#fff;outline-offset:-4px;outline-style:dotted;outline-width:thin;background-color:#137fec;}.iic-button-alt:hover:enabled,.aButton-left:hover:enabled,.aButton-right:hover:enabled,.ets-interaction-nav-btn:hover:enabled{background-color:#137fec;box-shadow:0 .07em .1em rgba(0,0,0,.25);}.iic-button-alt:active:enabled,.aButton-left:active:enabled,.aButton-right:active:enabled,.ets-interaction-nav-btn:active:enabled{background-color:#0060ac;box-shadow:none;}.iic-button-alt:disabled,.aButton-left:disabled,.aButton-right:disabled,.ets-interaction-nav-btn:disabled,.iic-button-alt .iic-button-alt.unselectable,.aButton-left .iic-button-alt.unselectable,.aButton-right .iic-button-alt.unselectable,.ets-interaction-nav-btn .iic-button-alt.unselectable,.iic-button-alt .unselectable.aButton-left,.aButton-left .unselectable.aButton-left,.aButton-right .unselectable.aButton-left,.ets-interaction-nav-btn .unselectable.aButton-left,.iic-button-alt .unselectable.aButton-right,.aButton-left .unselectable.aButton-right,.aButton-right .unselectable.aButton-right,.ets-interaction-nav-btn .unselectable.aButton-right,.iic-button-alt .unselectable.ets-interaction-nav-btn,.aButton-left .unselectable.ets-interaction-nav-btn,.aButton-right .unselectable.ets-interaction-nav-btn,.ets-interaction-nav-btn .unselectable.ets-interaction-nav-btn{background-color:#e5e5e5;color:#909090;cursor:default;pointer-events:none;}.iic-stage.iic-body-high .iic-button-alt,.iic-stage.iic-body-high .aButton-left,.iic-stage.iic-body-high .aButton-right,.iic-stage.iic-body-high .ets-interaction-nav-btn,#iic-stage.iic-body-high .iic-button-alt,#iic-stage.iic-body-high .aButton-left,#iic-stage.iic-body-high .aButton-right,#iic-stage.iic-body-high .ets-interaction-nav-btn{background-color:#143d66;border-color:#39f;box-shadow:unset;}.iic-stage.iic-body-high .iic-button-alt:hover:enabled,.iic-stage.iic-body-high .aButton-left:hover:enabled,.iic-stage.iic-body-high .aButton-right:hover:enabled,.iic-stage.iic-body-high .ets-interaction-nav-btn:hover:enabled,#iic-stage.iic-body-high .iic-button-alt:hover:enabled,#iic-stage.iic-body-high .aButton-left:hover:enabled,#iic-stage.iic-body-high .aButton-right:hover:enabled,#iic-stage.iic-body-high .ets-interaction-nav-btn:hover:enabled{background-color:#1f5c99;border-color:#39f;box-shadow:unset !important;}.iic-stage.iic-body-high .iic-button-alt:focus:enabled,.iic-stage.iic-body-high .aButton-left:focus:enabled,.iic-stage.iic-body-high .aButton-right:focus:enabled,.iic-stage.iic-body-high .ets-interaction-nav-btn:focus:enabled,#iic-stage.iic-body-high .iic-button-alt:focus:enabled,#iic-stage.iic-body-high .aButton-left:focus:enabled,#iic-stage.iic-body-high .aButton-right:focus:enabled,#iic-stage.iic-body-high .ets-interaction-nav-btn:focus:enabled{background-color:#1f5c99;box-shadow:unset !important;}.iic-stage.iic-body-high .iic-button-alt:disabled,.iic-stage.iic-body-high .aButton-left:disabled,.iic-stage.iic-body-high .aButton-right:disabled,.iic-stage.iic-body-high .ets-interaction-nav-btn:disabled,.iic-stage.iic-body-high .iic-button-alt.unselectable,.iic-stage.iic-body-high .unselectable.aButton-left,.iic-stage.iic-body-high .unselectable.aButton-right,.iic-stage.iic-body-high .unselectable.ets-interaction-nav-btn,#iic-stage.iic-body-high .iic-button-alt:disabled,#iic-stage.iic-body-high .aButton-left:disabled,#iic-stage.iic-body-high .aButton-right:disabled,#iic-stage.iic-body-high .ets-interaction-nav-btn:disabled,#iic-stage.iic-body-high .iic-button-alt.unselectable,#iic-stage.iic-body-high .unselectable.aButton-left,#iic-stage.iic-body-high .unselectable.aButton-right,#iic-stage.iic-body-high .unselectable.ets-interaction-nav-btn{background-color:#2e2e2e !important;border-color:#39f;border-color:transparent !important;color:#626262 !important;box-shadow:none;}.iic-stage.iic-body-low .iic-button-alt,.iic-stage.iic-body-low .aButton-left,.iic-stage.iic-body-low .aButton-right,.iic-stage.iic-body-low .ets-interaction-nav-btn,#iic-stage.iic-body-low .iic-button-alt,#iic-stage.iic-body-low .aButton-left,#iic-stage.iic-body-low .aButton-right,#iic-stage.iic-body-low .ets-interaction-nav-btn{background-color:#0068d1;}.iic-stage.iic-body-low .iic-button-alt:hover:enabled,.iic-stage.iic-body-low .aButton-left:hover:enabled,.iic-stage.iic-body-low .aButton-right:hover:enabled,.iic-stage.iic-body-low .ets-interaction-nav-btn:hover:enabled,.iic-stage.iic-body-low .iic-button-alt:focus:enabled,.iic-stage.iic-body-low .aButton-left:focus:enabled,.iic-stage.iic-body-low .aButton-right:focus:enabled,.iic-stage.iic-body-low .ets-interaction-nav-btn:focus:enabled,#iic-stage.iic-body-low .iic-button-alt:hover:enabled,#iic-stage.iic-body-low .aButton-left:hover:enabled,#iic-stage.iic-body-low .aButton-right:hover:enabled,#iic-stage.iic-body-low .ets-interaction-nav-btn:hover:enabled,#iic-stage.iic-body-low .iic-button-alt:focus:enabled,#iic-stage.iic-body-low .aButton-left:focus:enabled,#iic-stage.iic-body-low .aButton-right:focus:enabled,#iic-stage.iic-body-low .ets-interaction-nav-btn:focus:enabled{background-color:#137fec;}.iic-stage.iic-body-low .iic-button-alt:active:enabled,.iic-stage.iic-body-low .aButton-left:active:enabled,.iic-stage.iic-body-low .aButton-right:active:enabled,.iic-stage.iic-body-low .ets-interaction-nav-btn:active:enabled,#iic-stage.iic-body-low .iic-button-alt:active:enabled,#iic-stage.iic-body-low .aButton-left:active:enabled,#iic-stage.iic-body-low .aButton-right:active:enabled,#iic-stage.iic-body-low .ets-interaction-nav-btn:active:enabled{background-color:#0060ac;}.iic-stage.iic-body-low .iic-button-alt:disabled,.iic-stage.iic-body-low .aButton-left:disabled,.iic-stage.iic-body-low .aButton-right:disabled,.iic-stage.iic-body-low .ets-interaction-nav-btn:disabled,.iic-stage.iic-body-low .iic-button-alt.unselectable,.iic-stage.iic-body-low .unselectable.aButton-left,.iic-stage.iic-body-low .unselectable.aButton-right,.iic-stage.iic-body-low .unselectable.ets-interaction-nav-btn,#iic-stage.iic-body-low .iic-button-alt:disabled,#iic-stage.iic-body-low .aButton-left:disabled,#iic-stage.iic-body-low .aButton-right:disabled,#iic-stage.iic-body-low .ets-interaction-nav-btn:disabled,#iic-stage.iic-body-low .iic-button-alt.unselectable,#iic-stage.iic-body-low .unselectable.aButton-left,#iic-stage.iic-body-low .unselectable.aButton-right,#iic-stage.iic-body-low .unselectable.ets-interaction-nav-btn{background-color:#dcdcc8;}.iic-button-alt.up,.up.aButton-left,.up.aButton-right,.up.ets-interaction-nav-btn{border-radius:.33em !important;box-sizing:border-box;font-size:1em;height:1.65em;margin:unset;padding:0;position:absolute;text-align:center;vertical-align:middle;width:1.65em;top:0;left:50%;transform:translateX(-50%);}.iic-button-alt.up>img,.up.aButton-left>img,.up.aButton-right>img,.up.ets-interaction-nav-btn>img{transform:rotate(90deg);}.iic-button.left,button.left:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input.left[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-button-alt.left,.left.aButton-left,.left.aButton-right,.left.ets-interaction-nav-btn{border-radius:.33em !important;box-sizing:border-box;font-size:1em;height:1.65em;margin:unset;padding:0;position:absolute;text-align:center;vertical-align:middle;width:1.65em;top:50%;left:0;transform:translateY(-50%);}.iic-button.right,button.right:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input.right[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-button-alt.right,.right.aButton-left,.right.aButton-right,.right.ets-interaction-nav-btn{border-radius:.33em !important;box-sizing:border-box;font-size:1em;height:1.65em;margin:unset;padding:0;position:absolute;text-align:center;vertical-align:middle;width:1.65em;top:50%;right:0;transform:translateY(-50%);}.iic-button-alt.right>img,.right.aButton-left>img,.right.aButton-right>img,.right.ets-interaction-nav-btn>img{transform:rotate(180deg);}.iic-button.down,button.down:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),input.down[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-button-alt.down,.down.aButton-left,.down.aButton-right,.down.ets-interaction-nav-btn{border-radius:.33em !important;box-sizing:border-box;font-size:1em;height:1.65em;margin:unset;padding:0;position:absolute;text-align:center;vertical-align:middle;width:1.65em;bottom:0;left:50%;transform:translateX(-50%);}.iic-button-alt.down>img,.down.aButton-left>img,.down.aButton-right>img,.down.ets-interaction-nav-btn>img{transform:rotate(-90deg);}.aButton-left,.aButton-right{border-radius:1em;height:2em;margin-left:.5em !important;margin-right:.5em !important;max-height:2em;max-width:2em;padding:unset !important;width:2em;}.aButton-left span,.aButton-right span{position:unset !important;top:unset !important;left:unset !important;}.aButton-left span strong,.aButton-right span strong{font-size:inherit !important;}.plus-btn{width:3em;height:3em;background-size:1.1em;background-repeat:no-repeat;background-position:center;background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 10h-6v-6c0-1.105-0.895-2-2-2s-2 0.895-2 2v0 6h-6c-1.105 0-2 0.895-2 2s0.895 2 2 2v0h6v6c0 1.105 0.895 2 2 2s2-0.895 2-2v0-6h6c1.105 0 2-0.895 2-2s-0.895-2-2-2v0z" fill="#fff"/></svg>');}.plus-btn:disabled{background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 10h-6v-6c0-1.105-0.895-2-2-2s-2 0.895-2 2v0 6h-6c-1.105 0-2 0.895-2 2s0.895 2 2 2v0h6v6c0 1.105 0.895 2 2 2s2-0.895 2-2v0-6h6c1.105 0 2-0.895 2-2s-0.895-2-2-2v0z" fill="#909090"/></svg>');}.iic-body-low .plus-btn:disabled{background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 10h-6v-6c0-1.105-0.895-2-2-2s-2 0.895-2 2v0 6h-6c-1.105 0-2 0.895-2 2s0.895 2 2 2v0h6v6c0 1.105 0.895 2 2 2s2-0.895 2-2v0-6h6c1.105 0 2-0.895 2-2s-0.895-2-2-2v0z" fill="#8d8d7a"/></svg>');}.iic-body-high .plus-btn:disabled{background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 10h-6v-6c0-1.105-0.895-2-2-2s-2 0.895-2 2v0 6h-6c-1.105 0-2 0.895-2 2s0.895 2 2 2v0h6v6c0 1.105 0.895 2 2 2s2-0.895 2-2v0-6h6c1.105 0 2-0.895 2-2s-0.895-2-2-2v0z" fill="#626262"/></svg>');}.minus-btn{width:3em;height:3em;background-size:1.1em;background-repeat:no-repeat;background-position:center;background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 14h-16c-1.105 0-2-0.895-2-2s0.895-2 2-2v0h16c1.105 0 2 0.895 2 2s-0.895 2-2 2v0z" fill="#fff"/></svg>');}.minus-btn:disabled{background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 14h-16c-1.105 0-2-0.895-2-2s0.895-2 2-2v0h16c1.105 0 2 0.895 2 2s-0.895 2-2 2v0z" fill="#909090"/></svg>');}.iic-body-low .minus-btn:disabled{background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 14h-16c-1.105 0-2-0.895-2-2s0.895-2 2-2v0h16c1.105 0 2 0.895 2 2s-0.895 2-2 2v0z" fill="#8d8d7a"/></svg>');}.iic-body-high .minus-btn:disabled{background-image:url('data:image/svg+xml;utf8,<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"><path xmlns="http://www.w3.org/2000/svg" d="M20 14h-16c-1.105 0-2-0.895-2-2s0.895-2 2-2v0h16c1.105 0 2 0.895 2 2s-0.895 2-2 2v0z" fill="#626262"/></svg>');}.iic-checkbox{background-color:#fff;border-color:#ccc;border-radius:8px;border-style:solid;border-width:.1em;display:inline-flex;font-style:normal;font-size:24px;font-stretch:normal;font-variant-caps:normal;font-variant-ligatures:normal;font-variant-numeric:normal;height:2.3em;letter-spacing:normal;line-height:2.3em;margin-top:0;margin-right:4px;margin-bottom:6px;margin-left:0;padding-top:0;padding-right:.4em;padding-bottom:0;padding-left:0;text-decoration:none;text-align:center;vertical-align:top;zoom:1;}.iic-checkbox input[type=checkbox]:focus{outline-color:#000;outline-offset:.083em;outline-style:dotted;outline-width:1px;}.iic-checkbox .iic-input-bg{background-color:#dbedff;border-radius:.2em 0 0 .2em;display:flex;margin-right:.5em;padding:1em .6em;}.iic-checkbox label{white-space:nowrap;}.iic-checkbox input{align-self:center;-webkit-appearance:none;cursor:pointer;font-size:1em;}.iic-checkbox input:before{font-family:"icons";font-size:1em;font-style:normal;font-variant:normal;font-weight:normal;line-height:1;speak:none;text-transform:none;}.iic-checkbox input[type=checkbox]:not(:checked):before{content:"";}.iic-checkbox input[type=checkbox]:before{content:"";}.iic-checkbox:hover{border-color:#7fbfff;}#iic-stage.iic-body-high .iic-checkbox,.iic-stage.iic-body-high .iic-checkbox{background-color:#000 !important;border-color:#5a5a5a !important;color:#fff !important;}#iic-stage.iic-body-high .iic-checkbox input[type=checkbox],.iic-stage.iic-body-high .iic-checkbox input[type=checkbox]{color:#fff;}#iic-stage.iic-body-high .iic-checkbox input[type=checkbox]:focus,.iic-stage.iic-body-high .iic-checkbox input[type=checkbox]:focus{outline-color:#fff;}#iic-stage.iic-body-high .iic-input-bg,.iic-stage.iic-body-high .iic-input-bg{background-color:#191919 !important;}#iic-stage.iic-body-high .iic-checkbox:hover,.iic-stage.iic-body-high .iic-checkbox:hover{border-color:#7b98b5 !important;}#iic-stage.iic-body-low .iic-checkbox,.iic-stage.iic-body-low .iic-checkbox{background-color:#f9f9e9 !important;border-color:#abab9e !important;color:#000 !important;}#iic-stage.iic-body-low .iic-input-bg,.iic-stage.iic-body-low .iic-input-bg{background-color:#c7c7a9 !important;}#iic-stage.iic-body-low .iic-checkbox:hover,.iic-stage.iic-body-low .iic-checkbox:hover{border-color:#838377 !important;}#iic-stage.iic-tts .iic-checkbox,.iic-checkbox.disabled,.iic-checkbox input[disabled]{border-color:#ccc;opacity:.3;}#iic-stage.iic-tts .iic-checkbox .iic-input-bg,.iic-checkbox.disabled .iic-input-bg,.iic-checkbox input[disabled] .iic-input-bg{background-color:#f3f9ff;border-radius:.2em 0 0 .2em;}#iic-stage.iic-tts .iic-checkbox .iic-input-bg input,.iic-checkbox.disabled .iic-input-bg input,.iic-checkbox input[disabled] .iic-input-bg input{color:rgba(0,0,0,.3);outline:none;}#iic-stage.iic-body-high.iic-tts .iic-checkbox,#iic-stage.iic-body-high .iic-checkbox.disabled,#iic-stage.iic-body-high .iic-checkbox input[disabled]{border-color:#5a5a5a !important;}#iic-stage.iic-body-high.iic-tts .iic-checkbox .iic-input-bg,#iic-stage.iic-body-high .iic-checkbox.disabled .iic-input-bg,#iic-stage.iic-body-high .iic-checkbox input[disabled] .iic-input-bg{background-color:#000 !important;}#iic-stage.iic-body-high.iic-tts .iic-checkbox .iic-input-bg input,#iic-stage.iic-body-high .iic-checkbox.disabled .iic-input-bg input,#iic-stage.iic-body-high .iic-checkbox input[disabled] .iic-input-bg input{color:rgba(255,255,255,.2) !important;}#iic-stage.iic-body-low.iic-tts,#iic-stage.iic-body-low .iic-checkbox.disabled{border-color:#abab9e !important;}#iic-stage.iic-body-low.iic-tts .iic-input-bg,#iic-stage.iic-body-low .iic-checkbox.disabled .iic-input-bg{background-color:#ecebd3 !important;}#iic-stage.iic-body-low.iic-tts .iic-input-bg input,#iic-stage.iic-body-low .iic-checkbox.disabled .iic-input-bg input{color:rgba(0,0,0,.3) !important;}.iic-container{border-color:#e5e5e5;border-radius:.56em;border-style:solid;border-width:.1em;box-sizing:border-box;display:flex;flex-basis:auto;padding-bottom:.833em;padding-left:1.33em;padding-right:1.33em;padding-top:0;position:absolute;}.iic-container>.header{box-sizing:border-box;display:block;font-family:Calibri,Arial,sans-serif;font-size:1.33em;font-weight:700;line-height:1.6em;min-height:1.8em;position:relative;text-align:center;width:100%;}.iic-container>.contents{box-sizing:border-box;display:block;flex-grow:1;height:auto;position:relative;width:100%;}.iic-container.buttons{border-color:transparent !important;border-width:0 !important;box-sizing:border-box;display:block;height:auto;padding-bottom:0 !important;padding-right:0 !important;position:unset !important;}.iic-container.buttons>.iic-button,.iic-container.buttons>button:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn),.iic-container.buttons>input[type="button"]:not(.iic-button-alt):not(.aButton-left):not(.aButton-right):not(.ets-interaction-nav-btn){margin-left:1em;margin-right:0 !important;}.iic-source-tray,rect.ets-interaction-boxRect,rect.ets-interaction-rectbg-default,rect.ets-interaction-rectbg-low,rect.clonePolygonGroupContainer{stroke:#bbb !important;stroke-width:1 !important;fill:#ececec !important;}.iic-body-high .iic-source-tray,.iic-body-high rect.ets-interaction-rectbg-default,.iic-body-high rect.ets-interaction-boxRect,rect.ets-interaction-rectbg-high,.iic-body-high rect.clonePolygonGroupContainer{stroke:#bbb !important;stroke-width:1 !important;fill:#292929 !important;}.etsItemPart-button-group,.etsItemPart-style-selection-div{font-size:1em;border-radius:.2em;border:2px solid #ccc;padding:.5em .76em .76em;margin-bottom:1em;position:relative;}.iic-body-high .etsItemPart-button-group,.iic-body-high .etsItemPart-style-selection-div{border-color:#757575;}.etsItemPart-button-group-text,.etsItemPart-style-text{text-align:center;color:#000;}.iic-body-high .etsItemPart-button-group-text,.iic-body-high .etsItemPart-style-text{color:#ccc;}.segmented-control{border:none;color:#0855b2;display:inline-block;margin:0 0 1.11em;padding:0;}.sc-horizontal{display:flex;}.segmented-control input[type=radio]{opacity:0;position:absolute;}.segmented-control label{align-items:center;border:.083em solid #949494;border-bottom:none;cursor:pointer;display:flex;line-height:1;padding:.458em .583em;position:relative;transition:background .2s,border .2s;}.segmented-control label:first-of-type{border-radius:.333em .333em 0 0;}.segmented-control label:last-of-type{border-bottom:.083em solid #949494;border-radius:0 0 .333em .333em;}.segmented-control label:hover{background:#d6ebff;}html.can-touch .segmented-control label:hover{background:0 0;}html.can-touch .segmented-control label:active{background:#d6ebff;}.segmented-control input[type=radio]:checked+label{background:#0855b2;border-color:transparent;color:#fff;pointer-events:none;}.segmented-control input[type=radio]:checked+label+input+label{border-top-color:#0855b2;}.segmented-control input[type=radio][disabled]+label{background:#e5e5e5;border-color:transparent;color:#909090;cursor:default;}.segmented-control input[type=radio]:checked[disabled]+label{background:#909090;border-color:transparent;color:#e5e5e5;}.segmented-control input[type=radio]:checked[disabled]+label+input+label{border-top-color:#909090;}.segmented-control input[type=radio]+label::after{border-left:.083em solid transparent;border-right:.083em solid transparent;content:'';display:block;height:.083em;left:-.083em;position:absolute;right:-.083em;top:100%;transition:background .2s,border .2s;z-index:1;}.segmented-control input[type=radio]:checked:not(:last-of-type)+label::after{background:#0855b2;}.segmented-control input[type=radio]:checked:not(:last-of-type)[disabled]+label::after{background:#909090;}.segmented-control input[type=radio]:focus+label::before{border:1px dotted;content:'';display:block;position:absolute;bottom:2px;top:2px;left:2px;right:2px;}.segmented-control input[type=radio]:first-of-type:focus+label::before{border-radius:.25em .25em 0 0;}.segmented-control input[type=radio]:last-of-type:focus+label::before{border-radius:0 0 .25em .25em;}.segmented-control label span:only-child{text-align:center;width:100%;}.sc-horizontal label{justify-content:center;border-bottom:.083em solid #949494;border-right:none;width:100%;}.sc-horizontal label:first-of-type{border-radius:.333em 0 0 .333em;}.sc-horizontal label:last-of-type{border-radius:0 .333em .333em 0;border-right:.083em solid #949494;}.sc-horizontal input[type=radio]:checked+label+input+label{border-left-color:#0855b2;border-top-color:#949494;}.sc-horizontal input[type=radio]:checked[disabled]+label+input+label{border-left-color:#949494;border-top-color:transparent;}.sc-horizontal input[type=radio]+label::after{border:none;border-bottom:.083em solid transparent;border-top:.083em solid transparent;bottom:-.083em;height:100%;left:100%;right:-.083em;top:-.083em;width:.083em;}.sc-horizontal input[type=radio]:first-of-type:focus+label::before{border-radius:.25em 0 0 .25em;}.sc-horizontal input[type=radio]:last-of-type:focus+label::before{border-radius:0 .25em .25em 0;}.iic-body-high .segmented-control{color:#66b1ff;}.iic-body-high .segmented-control label{border-color:#999;}.iic-body-high .segmented-control label:hover{background:#2a2a2a;}.iic-body-high html.can-touch .segmented-control label:hover{background:none;}.iic-body-high html.can-touch .segmented-control label:active{background:#2a2a2a;}.iic-body-high .segmented-control input[type="radio"]:checked+label{background:#1d5995;border-left-color:#66b2ff;border-right-color:#66b2ff;border-top-color:#66b2ff;}.iic-body-high .segmented-control input[type="radio"]:first-of-type:checked+label{border-top-color:#66b2ff;}.iic-body-high .segmented-control input[type="radio"]:last-of-type:checked+label{border-bottom-color:#66b2ff;}.iic-body-high .segmented-control input[type="radio"]:checked+label+input+label{border-top-color:#66b2ff;}.iic-body-high .segmented-control input[type="radio"][disabled]+label{background:#2a2a2a;color:#626262;border-color:transparent;}.iic-body-high .segmented-control input[type="radio"]:checked[disabled]+label{background:#626262;border-left-color:#626262;border-right-color:#626262;color:#2a2a2a;}.iic-body-high .segmented-control input[type="radio"]:checked[disabled]+label+input+label{border-top-color:#626262;}.iic-body-high .segmented-control input[type="radio"]:first-of-type:checked[disabled]+label{border-top-color:#626262;}.iic-body-high .segmented-control input[type="radio"]:last-of-type:checked[disabled]+label{border-bottom-color:#626262;}.iic-body-high .segmented-control input[type="radio"]:checked:not(:last-of-type)+label::after{background:#66b2ff;border-color:#66b2ff;}.iic-body-high .segmented-control input[type="radio"]:checked:not(:last-of-type)[disabled]+label::after{background:#626262;border-color:transparent;}.iic-body-high .sc-horizontal input[type="radio"]:checked+label+input+label{border-top-color:#999;}.iic-body-high .sc-horizontal input[type="radio"]:checked+label{border-bottom-color:#66b2ff;}.iic-body-high .sc-horizontal input[type="radio"]:checked[disabled]+label{border-color:transparent;}.iic-body-high .sc-horizontal input[type="radio"]:checked[disabled]+label+input+label{border-top-color:transparent;}.iic-body-high .sc-horizontal input[type="radio"]:not(:last-of-type)+label::after{border-bottom:.083em solid transparent;border-top:.083em solid transparent;}.iic-body-low .segmented-control input[type="radio"][disabled]+label{background:#dcdcc8;color:#8d8d7a;}.iic-body-low .segmented-control input[type="radio"]:checked[disabled]+label{background:#8d8d7a;border-left-color:#8d8d7a;border-right-color:#8d8d7a;color:#dcdcc8;}.iic-body-low .segmented-control input[type="radio"]:checked[disabled]+label+input+label{border-top-color:#8d8d7a;}.iic-body-low .segmented-control input[type="radio"]:first-of-type:checked[disabled]+label{border-top-color:#8d8d7a;}.iic-body-low .segmented-control input[type="radio"]:last-of-type:checked[disabled]+label{border-bottom-color:#8d8d7a;}.iic-body-low .segmented-control input[type="radio"]:checked:not(:last-of-type)[disabled]+label::after{background:#8d8d7a;border-color:transparent;}.iic-body-low .sc-horizontal input[type="radio"]:checked[disabled]+label+input+label{border-top-color:transparent;}.iic-body-low .segmented-control input[type="radio"][disabled]+label .sc-icon-stroke{fill:#dcdcc8;}.segmented-control input[type=radio]+label .radio-shape{stroke:#fff;stroke-width:2px;stroke-linejoin:round;}.iic-body-high .segmented-control input[type=radio]+label .radio-shape{stroke:transparent;}.iic-body-high .segmented-control input[type=radio]:checked+label .radio-shape{stroke:#fff;}.iic-input-text,input[type="text"],input[type="number"],input[type="string"]{background-color:#fff;border-color:#595959;border-radius:0;border-style:solid;border-width:thin;box-shadow:inset 0 0 3px 1px #999;font-size:1.2em;line-height:1.5em;text-align:center;}.iic-input-text:disabled,input[type="text"]:disabled,input[type="number"]:disabled,input[type="string"]:disabled,.iic-input-text[disabled],input[disabled][type="text"],input[disabled][type="number"],input[disabled][type="string"]{background-color:#e5e5e5;border-color:transparent;box-shadow:none;}.iic-stage.iic-body-low .iic-input-text:disabled,.iic-stage.iic-body-low input[type="text"]:disabled,.iic-stage.iic-body-low input[type="number"]:disabled,.iic-stage.iic-body-low input[type="string"]:disabled,.iic-stage.iic-body-low .iic-input-text[disabled],.iic-stage.iic-body-low input[disabled][type="text"],.iic-stage.iic-body-low input[disabled][type="number"],.iic-stage.iic-body-low input[disabled][type="string"],#iic-stage.iic-body-low .iic-input-text:disabled,#iic-stage.iic-body-low input[type="text"]:disabled,#iic-stage.iic-body-low input[type="number"]:disabled,#iic-stage.iic-body-low input[type="string"]:disabled,#iic-stage.iic-body-low .iic-input-text[disabled],#iic-stage.iic-body-low input[disabled][type="text"],#iic-stage.iic-body-low input[disabled][type="number"],#iic-stage.iic-body-low input[disabled][type="string"]{background-color:#dcdcc8;}.ets-interaction-itemCir-hover,.iic-body-low .ets-interaction-itemCir-hover,.upDownControlTouchDotGraphic_default,.upDownControlTouchDotGraphic_low,.polygonObject_touchDot,.pointGroup_ring>.formDot,.touchDotObject_default,.touchDotObject_low{fill:rgba(255,255,255,0) !important;stroke:#949494 !important;stroke-width:2 !important;stroke-opacity:1 !important;fill-opacity:1 !important;r:25;}.iic-body-high .ets-interaction-itemCir-hover,.upDownControlTouchDotGraphic_high,.iic-body-high .polygonObject_touchDot,.iic-body-high .pointGroup_ring>.formDot,.touchDotObject_high{fill:rgba(100,100,100,0) !important;stroke:#8f8f8f !important;}.ets-interaction-drager,.ets-interaction-drager2,.outerCircle,.iic-body-default .ets-interaction-BoxAndWhisker-cir+circle{fill:rgba(255,255,255,.5) !important;stroke:#949494 !important;stroke-width:2 !important;stroke-opacity:1 !important;fill-opacity:1 !important;r:25;}.iic-body-high .ets-interaction-drager,.iic-body-high .ets-interaction-drager2,.iic-body-high .outerCircle,.iic-body-high .ets-interaction-BoxAndWhisker-cir+circle{fill:rgba(0,0,0,.5) !important;stroke:#8f8f8f !important;stroke-width:2 !important;}.iic-body-low .ets-interaction-drager,.iic-body-low .ets-interaction-drager2,.iic-body-low .outerCircle,.iic-body-low .ets-interaction-BoxAndWhisker-cir+circle{fill:#f9f9e9 !important;fill-opacity:.5 !important;stroke:#949494 !important;stroke-width:2 !important;}.ets-interaction-gridCircle-default{stroke:none !important;fill:#949494 !important;}.ets-interaction-gridCircle-high,.iic-body-high .ets-interaction-gridCircle-default{stroke:none !important;fill:#949494 !important;}.ets-interaction-gridCircle-low{stroke:none !important;fill:#949494 !important;}.tick line,.ets-interaction-gridLineMajor-default,.ets-interaction-gridLineMajor-low{stroke:#949494 !important;stroke-width:2.5px !important;}.iic-body-high .tick line,.x_axisHigh .tick line,.ets-interaction-gridLineMajor-high,.iic-body-high .ets-interaction-gridLineMajor-default{stroke:#757575 !important;stroke-width:2.5px !important;}.grid_minor .tick line,.ets-interaction-gridLineMinor-default,.ets-interaction-gridLineMinor-low{stroke:#949494 !important;stroke-width:1px !important;opacity:1 !important;stroke-linecap:round;}.iic-body-high .grid_minor .tick line,.iic-body-high .ets-interaction-gridLineMinor-default,.iic-body-high .ets-interaction-gridLineMinor-low,.ets-interaction-gridLineMinor-high{stroke:#757575 !important;stroke-width:1px !important;opacity:1 !important;stroke-linecap:round;}text.barText{transform:translate(0,-15px);text-anchor:middle;font-weight:400 !important;fill:black;text-shadow:.05em .05em .1em #fff,-.05em -.05em .1em #fff,.05em -.05em .1em #fff,-.05em .05em .1em #fff,.1em .1em .1em #fff,-.1em -.1em .1em #fff,.1em -.1em .1em #fff,-.1em .1em .1em #fff,.15em .15em .2em #fff,-.15em -.15em .2em #fff,.15em -.15em .2em #fff,-.15em .15em .2em #fff;font-size:20px;}.iic-body-high text.barText{fill:white;text-shadow:.05em .05em .1em #000,-.05em -.05em .1em #000,.05em -.05em .1em #000,-.05em .05em .1em #000,.1em .1em .1em #000,-.1em -.1em .1em #000,.1em -.1em .1em #000,-.1em .1em .1em #000,.15em .15em .2em #000,-.15em -.15em .2em #000,.15em -.15em .2em #000,-.15em .15em .2em #000;}.iic-body-low text.barText{fill:black;text-shadow:.05em .05em .1em #f9f9e9,-.05em -.05em .1em #f9f9e9,.05em -.05em .1em #f9f9e9,-.05em .05em .1em #f9f9e9,.1em .1em .1em #f9f9e9,-.1em -.1em .1em #f9f9e9,.1em -.1em .1em #f9f9e9,-.1em .1em .1em #f9f9e9,.15em .15em .2em #f9f9e9,-.15em -.15em .2em #f9f9e9,.15em -.15em .2em #f9f9e9,-.15em .15em .2em #f9f9e9;}text.ets-interaction-locText{transform:translate(0,-.5em);font-weight:700 !important;fill:black !important;stroke:white;paint-order:stroke;stroke-width:4;text-shadow:.02em .02em .04em #fff,-.02em -.02em .04em #fff,.02em -.02em .04em #fff,-.02em .02em .04em #fff,.04em .04em .04em #fff,-.04em -.04em .04em #fff,.04em -.04em .04em #fff,-.04em .04em .04em #fff,.06em .06em .1em #fff,-.06em -.06em .1em #fff,.06em -.06em .1em #fff,-.06em .06em .1em #fff;font-size:1em !important;}.iic-body-low text.ets-interaction-locText{fill:black !important;stroke:#f9f9e9;paint-order:stroke;stroke-width:4;text-shadow:.02em .02em .04em #f9f9e9,-.02em -.02em .04em #f9f9e9,.02em -.02em .04em #f9f9e9,-.02em .02em .04em #f9f9e9,.04em .04em .04em #f9f9e9,-.04em -.04em .04em #f9f9e9,.04em -.04em .04em #f9f9e9,-.04em .04em .04em #f9f9e9,.06em .06em .1em #f9f9e9,-.06em -.06em .1em #f9f9e9,.06em -.06em .1em #f9f9e9,-.06em .06em .1em #f9f9e9;}.iic-body-high text.ets-interaction-locText,.ets-interaction-locText-high{fill:white !important;stroke:black;paint-order:stroke;stroke-width:4;text-shadow:.02em .02em .04em #000,-.02em -.02em .04em #000,.02em -.02em .04em #000,-.02em .02em .04em #000,.04em .04em .04em #000,-.04em -.04em .04em #000,.04em -.04em .04em #000,-.04em .04em .04em #000,.06em .06em .1em #000,-.06em -.06em .1em #000,.06em -.06em .1em #000,-.06em .06em .1em #000;}

/*
    * Use this file to override the IIC-USE-Library Styles
*/


/* -------------- Future Library -------------- */

:root {
	--dc1: #949494;
	--dc2: #484848;
	--dc1high: #595959;	
	--dc2high: #aaaaaa;
	
	--baw-stroke: #333333;
	--baw-stroke-hover: #000000;
	--baw-blue-fill: #B8E2FF;
	--baw-blue-fill-hover: #72C1F7;
	--baw-blue-fill-hc: #003F75;
	--baw-blue-stroke-hc: #73BEFF;
	--baw-blue-fill-hover-hc: #0D64A0;
	--baw-blue-stroke-hover-hc: #C9E8FF;
	--baw-indigo-fill: #C2D3FF;
	--baw-indigo-fill-hover: #7FA2FA;
	--baw-indigo-fill-hc: #18317A;
	--baw-indigo-stroke-hc: #9CB7FF;
	--baw-indigo-fill-hover-hc: #3150A8;
	--baw-indigo-stroke-hover-hc: #C9D8FF;
	--baw-green-fill: #B1E0B4;
	--baw-green-fill-hover: #64CE6A;
	--baw-green-fill-hc: #0D6913;
	--baw-green-stroke-hc: #7AE382;
	--baw-green-fill-hover-hc: #1F9427;
	--baw-green-stroke-hover-hc: #C2FFC7;
	--baw-purple-fill: #DDCAFC;
	--baw-purple-fill-hover: #B38AF7;
	--baw-purple-fill-hc: #421F7D;
	--baw-purple-stroke-hc: #C099FF;
	--baw-purple-fill-hover-hc: #693FB0;
	--baw-purple-stroke-hover-hc: #E0CCFF;
	--baw-orange-fill: #FCC9AD;
	--baw-orange-fill-hover: #E19469;
	--baw-orange-fill-hc: #702C06;
	--baw-orange-stroke-hc: #E3AA8B;
	--baw-orange-fill-hover-hc: #A14817;
	--baw-orange-stroke-hover-hc: #FFDAC7;
	--baw-teal-fill: #A9DEDA;
	--baw-teal-fill-hover: #52BAB2;
	--baw-teal-fill-hc: #025751;
	--baw-teal-stroke-hc: #94D1CD;
	--baw-teal-fill-hover-hc: #128C83;
	--baw-teal-stroke-hover-hc: #CFFFFB;
	--baw-tan-fill: #E9D293;
	--baw-tan-fill-hover: #CDAA3F;
	--baw-tan-fill-hc: #6B4E01;
	--baw-tan-stroke-hc: #E9D293;
	--baw-tan-fill-hover-hc: #9E7609;
	--baw-tan-stroke-hover-hc: #FFF2CC;
}
.disabled * {
	pointer-events: none;
}
.disabled .innerCircle, .disabled .ets-interaction-BoxAndWhisker-cir {
	fill: #e5e5e5 !important;
	stroke: #aaa !important;
}
.disabled.iic-body-high .innerCircle, .iic-body-high.disabled .ets-interaction-BoxAndWhisker-cir {
	fill: #2a2a2a !important;
	stroke: #626262 !important;
}
.disabled.iic-body-low .innerCircle, .iic-body-low.disabled .ets-interaction-BoxAndWhisker-cir {
	fill: #dcdcc8 !important;
	stroke: #b7b79e !important;
}

#etsItemPartrestartButtonID, .iic-reset:last-child, .ets-interaction-btn-classic:last-child, .rest_main:last-child, .rest_main2:last-child, .resetDiv .aButton:last-child {
	margin-left: 1em !important;
}
/* -------------- Component Styles -------------- */

/*outercircle z-order fix temporary
.iic-body-default .ets-interaction-BoxAndWhisker-cir + circle, .iic-body-low .ets-interaction-BoxAndWhisker-cir + circle {
		mix-blend-mode: darken;
}
.iic-body-high .ets-interaction-BoxAndWhisker-cir + circle {
		mix-blend-mode: lighten;		
}*/

g.iic-drag-group *:not(circle):not(text) {
	stroke-linejoin: round;
	stroke-linecap: round;
	transition: fill .2s ease-out;
}
/*Drag state stroke-width change*/
g.drag-active *:not(circle):not(text), g.iic-drag-group.drag-active *:not(circle):not(text) {
	stroke-width: 7px !important;
}
/*Box Colors*/
g.iic-drag-group.blue *:not(circle):not(text) {
	fill: var(--baw-blue-fill) !important;
}
g.iic-drag-group.indigo *:not(circle):not(text) {
	fill: var(--baw-indigo-fill) !important;
}
g.iic-drag-group.green *:not(circle):not(text) {
	fill: var(--baw-green-fill) !important;
}
g.iic-drag-group.purple *:not(circle):not(text) {
	fill: var(--baw-purple-fill) !important;
}
g.iic-drag-group.orange *:not(circle):not(text) {
	fill: var(--baw-orange-fill) !important;
}
g.iic-drag-group.teal *:not(circle):not(text) {
	fill: var(--baw-teal-fill) !important;
}
g.iic-drag-group.tan *:not(circle):not(text) {
	fill: var(--baw-tan-fill) !important;
}
/*Box Color Hovers*/
g.iic-drag-group.hover *:not(circle):not(text), g.iic-drag-group.drag-active *:not(circle):not(text) {
	stroke: var(--baw-stroke-hover) !important;
	cursor: move;
}
g.iic-drag-group.blue.hover *:not(circle):not(text), g.iic-drag-group.blue.drag-active *:not(circle):not(text) {
	fill: var(--baw-blue-fill-hover) !important;
}
g.iic-drag-group.indigo.hover *:not(circle):not(text), g.iic-drag-group.indigo.drag-active *:not(circle):not(text) {
	fill: var(--baw-indigo-fill-hover) !important;
}
g.iic-drag-group.green.hover *:not(circle):not(text), g.iic-drag-group.green.drag-active *:not(circle):not(text) {
	fill: var(--baw-green-fill-hover) !important;
}
g.iic-drag-group.purple.hover *:not(circle):not(text), g.iic-drag-group.purple.drag-active *:not(circle):not(text) {
	fill: var(--baw-purple-fill-hover) !important;
}
g.iic-drag-group.orange.hover *:not(circle):not(text), g.iic-drag-group.orange.drag-active *:not(circle):not(text) {
	fill: var(--baw-orange-fill-hover) !important;
}
g.iic-drag-group.teal.hover *:not(circle):not(text), g.iic-drag-group.teal.drag-active *:not(circle):not(text) {
	fill: var(--baw-teal-fill-hover) !important;
}
g.iic-drag-group.tan.hover *:not(circle):not(text), g.iic-drag-group.tan.drag-active *:not(circle):not(text) {
	fill: var(--baw-tan-fill-hover) !important;
}
/*Box Color HC*/
.iic-body-high g.iic-drag-group.blue *:not(circle):not(text) {
	fill: var(--baw-blue-fill-hc) !important;
	stroke: var(--baw-blue-stroke-hc) !important;
}
.iic-body-high g.iic-drag-group.indigo *:not(circle):not(text) {
	fill: var(--baw-indigo-fill-hc) !important;
	stroke: var(--baw-indigo-stroke-hc) !important;
}
.iic-body-high g.iic-drag-group.green *:not(circle):not(text) {
	fill: var(--baw-green-fill-hc) !important;
	stroke: var(--baw-green-stroke-hc) !important;
}
.iic-body-high g.iic-drag-group.purple *:not(circle):not(text) {
	fill: var(--baw-purple-fill-hc) !important;
	stroke: var(--baw-purple-stroke-hc) !important;
}
.iic-body-high g.iic-drag-group.orange *:not(circle):not(text) {
	fill: var(--baw-orange-fill-hc) !important;
	stroke: var(--baw-orange-stroke-hc) !important;
}
.iic-body-high g.iic-drag-group.teal *:not(circle):not(text) {
	fill: var(--baw-teal-fill-hc) !important;
	stroke: var(--baw-teal-stroke-hc) !important;
}
.iic-body-high g.iic-drag-group.tan *:not(circle):not(text) {
	fill: var(--baw-tan-fill-hc) !important;
	stroke: var(--baw-tan-stroke-hc) !important;
}
/*Box Color HC Hovers*/
.iic-body-high g.iic-drag-group.blue.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.blue.drag-active *:not(circle):not(text) {
	fill: var(--baw-blue-fill-hover-hc) !important;
	stroke: var(--baw-blue-stroke-hover-hc) !important;
}
.iic-body-high g.iic-drag-group.indigo.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.indigo.drag-active *:not(circle):not(text) {
	fill: var(--baw-indigo-fill-hover-hc) !important;
	stroke: var(--baw-indigo-stroke-hover-hc) !important;
}
.iic-body-high g.iic-drag-group.green.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.green.drag-active *:not(circle):not(text) {
	fill: var(--baw-green-fill-hover-hc) !important;
	stroke: var(--baw-green-stroke-hover-hc) !important;
}
.iic-body-high g.iic-drag-group.purple.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.purple.drag-active *:not(circle):not(text) {
	fill: var(--baw-purple-fill-hover-hc) !important;
	stroke: var(--baw-purple-stroke-hover-hc) !important;
}
.iic-body-high g.iic-drag-group.orange.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.orange.drag-active *:not(circle):not(text) {
	fill: var(--baw-orange-fill-hover-hc) !important;
	stroke: var(--baw-orange-stroke-hover-hc) !important;
}
.iic-body-high g.iic-drag-group.teal.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.teal.drag-active *:not(circle):not(text) {
	fill: var(--baw-teal-fill-hover-hc) !important;
	stroke: var(--baw-teal-stroke-hover-hc) !important;
}
.iic-body-high g.iic-drag-group.tan.hover *:not(circle):not(text), .iic-body-high g.iic-drag-group.tan.drag-active *:not(circle):not(text) {
	fill: var(--baw-tan-fill-hover-hc) !important;
	stroke: var(--baw-tan-stroke-hover-hc) !important;
}
/*Mark for Delete*/
g.iic-drag-group.mark-for-delete circle {
	display: none;
}
g.iic-drag-group.mark-for-delete.hover *:not(circle):not(text), g.iic-drag-group.mark-for-delete.drag-active *:not(circle):not(text) {
	fill-opacity: 0.3;
	stroke-opacity: 0.3;
}
/* 
.focus-BoxAndWhisker-rect {
    outline: thin dotted black !important;
    outline-offset: 0.25em !important;       
	
}
.iic-body-high .focus-BoxAndWhisker-rect {
    outline: thin dotted white !important;
    outline-offset: 0.25em !important;
}*/


.iic-title-label {
	font-size: 1em;
	text-transform: uppercase;
	font-weight: 700;
}
.iic-body-high .iic-title-label {
	color: #ccc;
	fill: #ccc; /*fallback for svg text*/
}
.iic-xAxis-label {
	font-size: 1em;
}
.iic-body-high .iic-xAxis-label {
	color: #ccc;
	fill: #ccc; /*fallback for svg text*/
}
/*box label color and theme*/
.iic-tick-label, .iic-boxplot-label, .iic-xAxis-label {
	font-size: 1em;
	fill: black;
	stroke: white;
	paint-order: stroke;
	stroke-width: 4;
	text-shadow: 0.02em 0.02em 0.04em white, -0.02em -0.02em 0.04em white, 0.02em -0.02em 0.04em white, -0.02em 0.02em 0.04em white, 0.04em 0.04em 0.04em white, -0.04em -0.04em 0.04em white, 0.04em -0.04em 0.04em white, -0.04em 0.04em 0.04em white, 0.06em 0.06em 0.1em white, -0.06em -0.06em 0.1em white, 0.06em -0.06em 0.1em white, -0.06em 0.06em 0.1em white;
	transform: translate(0, 0.1em);
}
.iic-tick-label {
	transform: translate(0, 0.4em);
}
.iic-body-low .iic-tick-label, .iic-body-low .iic-boxplot-label, .iic-body-low .iic-xAxis-label {
	font-size: 1em;
	fill: black;
	stroke: #f9f9e9;
	paint-order: stroke;
	stroke-width: 4;
	text-shadow: 0.02em 0.02em 0.04em #f9f9e9, -0.02em -0.02em 0.04em #f9f9e9, 0.02em -0.02em 0.04em #f9f9e9, -0.02em 0.02em 0.04em #f9f9e9, 0.04em 0.04em 0.04em #f9f9e9, -0.04em -0.04em 0.04em #f9f9e9, 0.04em -0.04em 0.04em #f9f9e9, -0.04em 0.04em 0.04em #f9f9e9, 0.06em 0.06em 0.1em #f9f9e9, -0.06em -0.06em 0.1em #f9f9e9, 0.06em -0.06em 0.1em #f9f9e9, -0.06em 0.06em 0.1em #f9f9e9;
}
.iic-body-high .iic-tick-label, .iic-body-high .iic-boxplot-label, .iic-body-high .iic-xAxis-label {
	font-size: 1em;
	fill: #bebebe;
	stroke: black;
	paint-order: stroke;
	stroke-width: 4;
	text-shadow: 0.02em 0.02em 0.04em black, -0.02em -0.02em 0.04em black, 0.02em -0.02em 0.04em black, -0.02em 0.02em 0.04em black, 0.04em 0.04em 0.04em black, -0.04em -0.04em 0.04em black, 0.04em -0.04em 0.04em black, -0.04em 0.04em 0.04em black, 0.06em 0.06em 0.1em black, -0.06em -0.06em 0.1em black, 0.06em -0.06em 0.1em black, -0.06em 0.06em 0.1em black;
}
.iic-body-high .iic-boxplot-label {
	fill: white;
}
.ets-interaction-BoxAndWhisker-rect {
	stroke: #333;
	stroke-width: 5 !important;
}
.ets-interaction-BoxAndWhisker-rect.outer {
	stroke-linecap: round;
}
.iic-body-high .ets-interaction-BoxAndWhisker-rect {
	stroke: #5EBEFC;
	stroke-width: 5 !important;
	fill: #024071 !important; /*remove if darkTheme param is added*/
}
.iic-body-default .ets-interaction-BoxAndWhisker-label-default {
	stroke: white;
	paint-order: stroke;
	stroke-width: 4;
	text-shadow: 0.02em 0.02em 0.04em #fff, -0.02em -0.02em 0.04em #fff, 0.02em -0.02em 0.04em #fff, -0.02em 0.02em 0.04em #fff, 0.04em 0.04em 0.04em #fff, -0.04em -0.04em 0.04em #fff, 0.04em -0.04em 0.04em #fff, -0.04em 0.04em 0.04em #fff, 0.06em 0.06em 0.1em #fff, -0.06em -0.06em 0.1em #fff, 0.06em -0.06em 0.1em #fff, -0.06em 0.06em 0.1em #fff;
}
.iic-body-low .ets-interaction-BoxAndWhisker-label-low, .iic-body-low .ets-interaction-BoxAndWhisker-label-default {
	stroke: #f9f9e9;
	paint-order: stroke;
	stroke-width: 4;
	text-shadow: 0.02em 0.02em 0.04em #f9f9e9, -0.02em -0.02em 0.04em #f9f9e9, 0.02em -0.02em 0.04em #f9f9e9, -0.02em 0.02em 0.04em #f9f9e9, 0.04em 0.04em 0.04em #f9f9e9, -0.04em -0.04em 0.04em #f9f9e9, 0.04em -0.04em 0.04em #f9f9e9, -0.04em 0.04em 0.04em #f9f9e9, 0.06em 0.06em 0.1em #f9f9e9, -0.06em -0.06em 0.1em #f9f9e9, 0.06em -0.06em 0.1em #f9f9e9, -0.06em 0.06em 0.1em #f9f9e9;
}
line.ets-interaction-itemLine, rect.ets-interaction-boxDragger, line.ets-interaction-itemCirEmpty, line.ets-interaction-centerLine {
	stroke-linecap: round;
	stroke-linejoin: round;
	stroke-width: 5 !important;
	transition: fill .2s ease-out;
}
/*.iic-body-high line.ets-interaction-itemLine, .iic-body-high rect.ets-interaction-boxDragger, .iic-body-high line.ets-interaction-itemCirEmpty, .iic-body-high line.ets-interaction-centerLine {
  stroke: #5EBEFC !important;
  fill: #024071 !important;
}*/

.ets-interaction-boxDragger.hover {
	fill: purple !important;
}
.iic-controlPoint {
}
.iic-controlPoint-drag, .iic-body-high .iic-controlPoint-drag, .iic-body-low .iic-controlPoint-drag {
	r: 12;
	transition: r .1s ease-out;
	cursor: ns-resize !important;
}
.iic-controlPoint-handler {
}
.iic-controlPoint-handler-hover {
}
.extra_xAxis {
	stroke: #000000;
	stroke-width: 3px;
	stroke-linecap: round;
}
.iic-body-high .extra_xAxis {
	stroke: #BEBEBE !important;
}
/*disabled source tray styles*/
g.disabled .ets-interaction-itemLine, g.disabled .ets-interaction-boxDragger, g.disabled .ets-interaction-centerLine {
	fill: var(--dc1) !important;
	stroke: var(--dc2) !important;
}
.iic-body-high g.disabled .ets-interaction-itemLine, .iic-body-high g.disabled .ets-interaction-boxDragger, .iic-body-high g.disabled .ets-interaction-centerLine {
	fill: var(--dc2) !important;
	stroke: var(--dc1) !important;
}
/*disabled grid styles*/
.disabled g.iic-drag-group *:not(circle):not(text) {
	fill: var(--dc1) !important;
	stroke: var(--dc2) !important;
}
.iic-body-high.disabled g.iic-drag-group *:not(circle):not(text) {
	fill: var(--dc2) !important;
	stroke: var(--dc1) !important;
}
.iic-drag-group.box-locked .ets-interaction-BoxAndWhisker-rect {
	fill: var(--dc1) !important;
	stroke: var(--dc2) !important;
}
.iic-body-high .iic-drag-group.box-locked .ets-interaction-BoxAndWhisker-rect {
	fill: var(--dc2) !important;
	stroke: var(--dc1) !important;
}
div#blockerDiv, .ets-interaction-blocker {
	background: white;
	fill: white;
	mix-blend-mode: color;
	opacity: 1 !important;
}
.iic-body-low div#blockerDiv, .iic-body-low .ets-interaction-blocker {
	background: #f9f9e9;
	fill: #f9f9e9;
	mix-blend-mode: color;
	opacity: 1 !important;
}
.iic-body-high-box-line {
	stroke: var(--baw-blue-stroke-hc) !important;
}
.iic-body-high-box-line-hover {
	stroke: var(--baw-blue-stroke-hover-hc) !important;
}

</style>`;

  return {
    applyCSS: function(p) {
      p.insertAdjacentHTML("afterbegin", css);
    }
  };
});
