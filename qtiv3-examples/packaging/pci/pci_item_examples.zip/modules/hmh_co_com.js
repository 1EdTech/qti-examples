{   "waitSeconds": 60,
    "paths": {
        "jquery": "https://code.jquery.com/jquery-2.2.2.min",
        "eve": "modules/lib/eve.js",
        "raphael": "modules/lib/raphael.js"
    }
}